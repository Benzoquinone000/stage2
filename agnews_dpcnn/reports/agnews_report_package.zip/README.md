# AG News report package

Contains final reports, figures, key result tables, core scripts, and small CSV/JSON logs for reproducibility. Large datasets and model checkpoints are intentionally excluded.
